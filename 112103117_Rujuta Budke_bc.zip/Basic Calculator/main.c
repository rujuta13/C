#include "header.h"
#include<stdio.h>
#include<string.h>
void main(){
	char A[10000];
	printf("bc\n");
	scanf("%s", A);
	int s = strlen(A);
	evaluate(A, s);
}